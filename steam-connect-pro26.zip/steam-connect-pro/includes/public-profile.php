<?php
if (!defined('ABSPATH')) exit;

/*
 * Public Steam User Profile Page
 */

function scp_public_profile_template() {

    if (!get_query_var('scp_steam_user')) return;

    $steam_id = sanitize_text_field(get_query_var('scp_steam_user'));

    if (!$steam_id) return;

    $steam_data = scp_get_steam_user_info($steam_id, true);
    $recent_games = scp_get_recent_games($steam_id);
    $owned_games = scp_get_owned_games($steam_id);

    /* Sort by playtime (DESC) */
    if(!empty($recent_games)){
        usort($recent_games, function($a,$b){
            return $b['playtime_forever'] <=> $a['playtime_forever'];
        });
    }

    if(!empty($owned_games)){
        usort($owned_games, function($a,$b){
            return $b['playtime_forever'] <=> $a['playtime_forever'];
        });
    }

    if (!$steam_data) {
        wp_die('Steam user not found');
    }

    $target_user_id = scp_find_user_by_steam_id($steam_id);

    $friend_state = 'none';
    $friend_button_meta = scp_friends_get_button_meta('none');
    if (is_user_logged_in() && $target_user_id) {
        $friend_state = scp_friends_get_relationship_state(get_current_user_id(), (int) $target_user_id);
        $friend_button_meta = scp_friends_get_button_meta($friend_state);
    }
    $steam_level = intval($steam_data['level']);
    $level_class = 'scp-level-basic';

    if ($steam_level >= 11 && $steam_level <= 30) {
        $level_class = 'scp-level-bronze';
    } elseif ($steam_level >= 31 && $steam_level <= 60) {
        $level_class = 'scp-level-silver';
    } elseif ($steam_level >= 61 && $steam_level <= 100) {
        $level_class = 'scp-level-gold';
    } elseif ($steam_level >= 101) {
        $level_class = 'scp-level-platinum';
    }

    $current_game_name = isset($steam_data['current_game_name']) ? $steam_data['current_game_name'] : '';
    $current_game_image = isset($steam_data['current_game_image']) ? $steam_data['current_game_image'] : '';

    get_header();

    ?>

    <div class="scp-public-profile">

        <article class="scp-public-card-pro" data-steamid="<?php echo esc_attr($steam_id); ?>">
            <div class="scp-current-game-corner">
                <div class="scp-current-game-box" data-has-game="<?php echo !empty($current_game_name) ? '1' : '0'; ?>">
                    <img src="<?php echo esc_url($current_game_image); ?>" alt="<?php echo esc_attr($current_game_name ? $current_game_name : 'Current Game'); ?>" class="scp-current-game-cover <?php echo empty($current_game_image) ? 'is-hidden' : ''; ?>">

                    <div class="scp-current-game-content">
                        <span class="scp-current-game-label">بازی در حال پلی</span>
                        <strong class="scp-current-game-name"><?php echo esc_html($current_game_name ? $current_game_name : 'در حال حاضر بازی‌ای در حال اجرا نیست'); ?></strong>
                    </div>
                </div>
            </div>

            <div class="scp-public-card-head">
                <div class="scp-avatar-presence-wrap <?php echo $target_user_id ? '' : 'no-site-user'; ?>" <?php if ($target_user_id) : ?>data-scp-site-user-id="<?php echo esc_attr((int) $target_user_id); ?>"<?php endif; ?>>
                    <img src="<?php echo esc_url($steam_data['avatar']); ?>" class="scp-avatar-large" alt="<?php echo esc_attr($steam_data['name']); ?>">
                    <?php if ($target_user_id) : ?>
                        <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                    <?php endif; ?>
                </div>

                <div class="scp-public-user-info">
                    <h2><?php echo esc_html($steam_data['name']); ?></h2>

                    <div class="scp-meta-row scp-meta-row-profile">
                        <span class="scp-level-badge <?php echo esc_attr($level_class); ?>" data-tooltip="<?php esc_attr_e('Steam Level', 'steam-connect-pro'); ?>">
                            <?php printf(esc_html__('Lv. %d', 'steam-connect-pro'), $steam_level); ?>
                        </span>

                        <span class="scp-online-status-profile <?php echo ($steam_data['online'] > 0 ? 'online' : 'offline'); ?>" data-tooltip="in steam">
                            <?php echo ($steam_data['online'] > 0 ? 'Online' : 'Offline'); ?>
                        </span>
                    </div>
                </div>
            </div>

            <div class="scp-public-actions">
                <?php if (is_user_logged_in() && $target_user_id && get_current_user_id() !== (int) $target_user_id) : ?>
                    <button type="button" class="scp-chat-launch scp-chat-launch-profile" data-target-user="<?php echo esc_attr((int) $target_user_id); ?>" data-target-name="<?php echo esc_attr($steam_data['name']); ?>">
                        💬 چت با این کاربر
                    </button>

                    <?php if ($friend_state === 'friends') : ?>
                        <div class="scp-friend-split" data-target-user="<?php echo esc_attr((int) $target_user_id); ?>">
                            <button type="button" class="scp-friend-btn is-friends" data-friend-state="friends" disabled>Friends</button>
                            <button type="button" class="scp-friend-btn is-remove" data-friend-action="remove" data-target-user="<?php echo esc_attr((int) $target_user_id); ?>">Remove Friend</button>
                        </div>
                    <?php else : ?>
                        <button type="button"
                                class="scp-friend-btn <?php echo esc_attr($friend_button_meta['class']); ?>"
                                data-target-user="<?php echo esc_attr((int) $target_user_id); ?>"
                                data-friend-state="<?php echo esc_attr($friend_state); ?>"
                                <?php disabled(!empty($friend_button_meta['disabled'])); ?>>
                            <?php echo esc_html($friend_button_meta['label']); ?>
                        </button>
                    <?php endif; ?>
                <?php endif; ?>

                <a href="<?php echo esc_url($steam_data['profile_url']); ?>" target="_blank" rel="noopener noreferrer" class="scp-profile-link-steami">
                    View Steam Profile
                </a>
            </div>
        </article>

        <div class="scp-section-header">
            <h3 class="scp-section-title">Recently Played</h3>
        </div>


        <div class="scp-games-grid">

        <?php if(!empty($recent_games)): ?>

        <?php foreach($recent_games as $game): ?>

        <div class="scp-game-card">

        <img src="https://cdn.cloudflare.steamstatic.com/steam/apps/<?php echo $game['appid']; ?>/header.jpg">

        <div class="scp-game-info">
        <strong><?php echo esc_html($game['name']); ?></strong>

        <div class="scp-playtime-badge">
            <?php echo round($game['playtime_forever']/60,1); ?> ساعت بازی
        </div>


        </div>
        </div>

        <?php endforeach; ?>

        <?php else: ?>
        <div class="scp-empty-state">
            هیچ بازی اخیری پیدا نشد
        </div>

        <?php endif; ?>

        </div>
        <div class="scp-section-header">
            <h3 class="scp-section-title">بازی‌هایی که این کاربر تجربه کرده</h3>
        </div>


        <div class="scp-games-grid">

        <?php if(!empty($owned_games)): ?>

        <?php foreach(array_slice($owned_games,0,24) as $game): ?>

        <div class="scp-game-card">

        <img src="https://cdn.cloudflare.steamstatic.com/steam/apps/<?php echo $game['appid']; ?>/header.jpg">

        <div class="scp-game-info">

        <strong><?php echo esc_html($game['name']); ?></strong>

        <div class="scp-playtime-badge">
            <?php echo round($game['playtime_forever']/60,1); ?> ساعت بازی
        </div>

        </div>
        </div>

        <?php endforeach; ?>

        <?php else: ?>
        <div class="scp-empty-state">
            هیچ بازی‌ای یافت نشد
        </div>

        <?php endif; ?>

        </div>

    </div> <!-- close scp-public-profile -->

    <?php

    get_footer();
    exit;
}

add_action('template_redirect', 'scp_public_profile_template');
