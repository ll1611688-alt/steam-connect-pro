<?php
if (!defined('ABSPATH')) {
    exit;
}

function scp_friends_table_requests() {
    global $wpdb;
    return $wpdb->prefix . 'scp_friend_requests';
}

function scp_friends_install_table() {
    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $table = scp_friends_table_requests();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE {$table} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        requester_id BIGINT UNSIGNED NOT NULL,
        receiver_id BIGINT UNSIGNED NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        acted_by BIGINT UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY requester_status (requester_id, status),
        KEY receiver_status (receiver_id, status),
        KEY pair_lookup (requester_id, receiver_id),
        KEY status_updated (status, updated_at)
    ) {$charset_collate};";

    dbDelta($sql);
}

function scp_friends_table_exists() {
    global $wpdb;

    $table = scp_friends_table_requests();
    $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));

    return ($found === $table);
}

function scp_friends_ensure_table() {
    if (scp_friends_table_exists()) {
        return true;
    }

    scp_friends_install_table();

    global $wpdb;
    $table = scp_friends_table_requests();
    $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));

    return ($found === $table);
}

add_action('init', function () {
    scp_friends_ensure_table();
});

function scp_friends_get_relationship_state($current_user_id, $target_user_id) {
    global $wpdb;

    $current_user_id = (int) $current_user_id;
    $target_user_id = (int) $target_user_id;

    if ($current_user_id <= 0 || $target_user_id <= 0) {
        return 'none';
    }

    if ($current_user_id === $target_user_id) {
        return 'self';
    }

    if (!scp_friends_ensure_table()) {
        return 'none';
    }

    $table = scp_friends_table_requests();

    $accepted = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$table}
         WHERE status = 'accepted'
           AND ((requester_id = %d AND receiver_id = %d)
             OR (requester_id = %d AND receiver_id = %d))
         ORDER BY id DESC
         LIMIT 1",
        $current_user_id,
        $target_user_id,
        $target_user_id,
        $current_user_id
    ));

    if ($accepted > 0) {
        return 'friends';
    }

    $outgoing = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$table}
         WHERE status = 'pending' AND requester_id = %d AND receiver_id = %d
         ORDER BY id DESC
         LIMIT 1",
        $current_user_id,
        $target_user_id
    ));

    if ($outgoing > 0) {
        return 'outgoing';
    }

    $incoming = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$table}
         WHERE status = 'pending' AND requester_id = %d AND receiver_id = %d
         ORDER BY id DESC
         LIMIT 1",
        $target_user_id,
        $current_user_id
    ));

    if ($incoming > 0) {
        return 'incoming';
    }

    return 'none';
}

function scp_friends_get_button_meta($state) {
    $meta_map = [
        'none' => [
            'label' => 'Add Friend',
            'class' => 'is-add',
            'disabled' => false,
        ],
        'outgoing' => [
            'label' => 'Cancel Invite',
            'class' => 'is-cancel',
            'disabled' => false,
        ],
        'incoming' => [
            'label' => 'Pending in Notifications',
            'class' => 'is-pending',
            'disabled' => true,
        ],
        'friends' => [
            'label' => 'Friends',
            'class' => 'is-friends',
            'disabled' => true,
        ],
        'self' => [
            'label' => 'Your Profile',
            'class' => 'is-self',
            'disabled' => true,
        ],
    ];

    return isset($meta_map[$state]) ? $meta_map[$state] : $meta_map['none'];
}

function scp_friends_get_friendship_since($user_a, $user_b) {
    global $wpdb;

    $user_a = (int) $user_a;
    $user_b = (int) $user_b;

    if ($user_a <= 0 || $user_b <= 0 || !scp_friends_ensure_table()) {
        return '';
    }

    $table = scp_friends_table_requests();
    $accepted_at = $wpdb->get_var($wpdb->prepare(
        "SELECT updated_at FROM {$table}
         WHERE status = 'accepted'
           AND ((requester_id = %d AND receiver_id = %d)
             OR (requester_id = %d AND receiver_id = %d))
         ORDER BY id DESC
         LIMIT 1",
        $user_a,
        $user_b,
        $user_b,
        $user_a
    ));

    return $accepted_at ? (string) $accepted_at : '';
}

function scp_friends_get_user_friends($user_id, $limit = 100) {
    global $wpdb;

    $user_id = (int) $user_id;
    $limit = max(1, min(500, (int) $limit));

    if ($user_id <= 0 || !scp_friends_ensure_table()) {
        return [];
    }

    $table = scp_friends_table_requests();
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT requester_id, receiver_id, updated_at
         FROM {$table}
         WHERE status = 'accepted' AND (requester_id = %d OR receiver_id = %d)
         ORDER BY updated_at DESC
         LIMIT %d",
        $user_id,
        $user_id,
        $limit
    ));

    $friends = [];
    foreach ($rows as $row) {
        $friend_id = ((int) $row->requester_id === $user_id) ? (int) $row->receiver_id : (int) $row->requester_id;
        if ($friend_id <= 0 || isset($friends[$friend_id])) {
            continue;
        }

        $payload = scp_chat_get_user_payload($friend_id);
        if (!$payload) {
            continue;
        }

        $steam_id = sanitize_text_field((string) get_user_meta($friend_id, 'steam_id', true));
        $since = mysql2date('U', $row->updated_at);

        $friends[$friend_id] = [
            'id' => $friend_id,
            'user' => $payload,
            'steam_id' => $steam_id,
            'public_profile_url' => $steam_id ? home_url('/steam-user/' . $steam_id) : '',
            'since_human' => human_time_diff($since, current_time('timestamp')),
            'since_iso' => mysql2date('c', $row->updated_at),
        ];
    }

    return array_values($friends);
}

function scp_friends_get_received_pending($user_id, $limit = 20) {
    global $wpdb;

    $user_id = (int) $user_id;
    $limit = max(1, min(50, (int) $limit));

    if ($user_id <= 0) {
        return [];
    }

    if (!scp_friends_ensure_table()) {
        return [];
    }

    $table = scp_friends_table_requests();
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table}
         WHERE receiver_id = %d AND status = 'pending'
         ORDER BY id DESC
         LIMIT %d",
        $user_id,
        $limit
    ));

    $items = [];
    foreach ($rows as $row) {
        $from = scp_chat_get_user_payload((int) $row->requester_id);
        if (!$from) {
            continue;
        }

        $items[] = [
            'request_id' => (int) $row->id,
            'from_user' => $from,
            'created_at' => mysql2date('c', $row->created_at),
        ];
    }

    return $items;
}

function scp_friends_shortcode_notifications() {
    if (!is_user_logged_in()) {
        return '';
    }

    $requests = scp_friends_get_received_pending(get_current_user_id(), 20);
    $count = count($requests);

    ob_start();
    ?>
    <div class="scp-notify" id="scp-notify-root">
        <button type="button" class="scp-notify-btn" id="scp-notify-toggle" aria-expanded="false" data-tooltip="اعلان">
    
    <span class="scp-notify-icon dashicons dashicons-bell" aria-hidden="true"></span>
    
    <span class="scp-notify-count <?php echo $count > 0 ? '' : 'is-hidden'; ?>" id="scp-notify-count">
        <?php echo esc_html((string) $count); ?>
    </span>

</button>

        <div class="scp-notify-panel" id="scp-notify-panel" hidden>
            <div class="scp-notify-head">اعلان‌ها</div>
            <div class="scp-notify-list" id="scp-notify-list">
                <?php if ($count > 0) : ?>
                    <?php foreach ($requests as $request) : ?>
                        <div class="scp-notify-item" data-request-id="<?php echo esc_attr((string) $request['request_id']); ?>">
                            <span class="scp-avatar-presence-wrap" data-scp-site-user-id="<?php echo esc_attr((string) $request['from_user']['id']); ?>">
                                <img src="<?php echo esc_url($request['from_user']['avatar']); ?>" alt="<?php echo esc_attr($request['from_user']['name']); ?>">
                                <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                            </span>
                            <div class="scp-notify-user-meta">
                                <strong><?php echo esc_html($request['from_user']['name']); ?></strong>
                                <span>درخواست دوستی ارسال کرده است</span>
                            </div>
                            <div class="scp-notify-actions">
                                <button type="button" class="scp-notify-accept" data-request-id="<?php echo esc_attr((string) $request['request_id']); ?>">قبول</button>
                                <button type="button" class="scp-notify-reject" data-request-id="<?php echo esc_attr((string) $request['request_id']); ?>">رد</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <div class="scp-notify-empty">اعلان جدیدی وجود ندارد</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('scp_notifications', 'scp_friends_shortcode_notifications');

add_action('wp_ajax_scp_send_friend_invite', function () {
    if (!scp_friends_ensure_table()) {
        wp_send_json_error(['message' => 'friends_table_missing'], 500);
    }

    global $wpdb;

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }

    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'scp-ajax')) {
        wp_send_json_error(['message' => 'invalid_nonce'], 400);
    }

    $current_user_id = get_current_user_id();
    $target_user_id = isset($_POST['target_user_id']) ? (int) $_POST['target_user_id'] : 0;

    if ($target_user_id <= 0 || $target_user_id === $current_user_id || !get_userdata($target_user_id)) {
        wp_send_json_error(['message' => 'invalid_target'], 400);
    }

    $state = scp_friends_get_relationship_state($current_user_id, $target_user_id);
    if ($state === 'friends') {
        wp_send_json_success(['state' => 'friends']);
    }
    if ($state === 'outgoing') {
        wp_send_json_success(['state' => 'outgoing']);
    }
    if ($state === 'incoming') {
        wp_send_json_success(['state' => 'incoming']);
    }

    $table = scp_friends_table_requests();
    $inserted = $wpdb->insert(
        $table,
        [
            'requester_id' => $current_user_id,
            'receiver_id' => $target_user_id,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ],
        ['%d', '%d', '%s', '%s', '%s']
    );

    if (!$inserted) {
        wp_send_json_error(['message' => 'invite_create_failed'], 500);
    }

    wp_send_json_success(['state' => 'outgoing']);
});

add_action('wp_ajax_scp_cancel_friend_invite', function () {
    if (!scp_friends_ensure_table()) {
        wp_send_json_error(['message' => 'friends_table_missing'], 500);
    }

    global $wpdb;

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }

    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'scp-ajax')) {
        wp_send_json_error(['message' => 'invalid_nonce'], 400);
    }

    $current_user_id = get_current_user_id();
    $target_user_id = isset($_POST['target_user_id']) ? (int) $_POST['target_user_id'] : 0;

    if ($target_user_id <= 0 || !get_userdata($target_user_id)) {
        wp_send_json_error(['message' => 'invalid_target'], 400);
    }

    $table = scp_friends_table_requests();
    $updated = $wpdb->query($wpdb->prepare(
        "UPDATE {$table}
         SET status = 'cancelled', acted_by = %d, updated_at = %s
         WHERE requester_id = %d AND receiver_id = %d AND status = 'pending'",
        $current_user_id,
        current_time('mysql'),
        $current_user_id,
        $target_user_id
    ));

    if ($updated === false) {
        wp_send_json_error(['message' => 'invite_cancel_failed'], 500);
    }

    wp_send_json_success(['state' => 'none']);
});

add_action('wp_ajax_scp_get_friend_requests', function () {
    if (!scp_friends_ensure_table()) {
        wp_send_json_error(['message' => 'friends_table_missing'], 500);
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }

    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'scp-ajax')) {
        wp_send_json_error(['message' => 'invalid_nonce'], 400);
    }

    $items = scp_friends_get_received_pending(get_current_user_id(), 20);
    wp_send_json_success([
        'count' => count($items),
        'items' => $items,
    ]);
});

add_action('wp_ajax_scp_respond_friend_invite', function () {
    if (!scp_friends_ensure_table()) {
        wp_send_json_error(['message' => 'friends_table_missing'], 500);
    }

    global $wpdb;

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }

    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'scp-ajax')) {
        wp_send_json_error(['message' => 'invalid_nonce'], 400);
    }

    $request_id = isset($_POST['request_id']) ? (int) $_POST['request_id'] : 0;
    $decision = isset($_POST['decision']) ? sanitize_key(wp_unslash($_POST['decision'])) : '';
    $current_user_id = get_current_user_id();

    if ($request_id <= 0 || !in_array($decision, ['accept', 'reject'], true)) {
        wp_send_json_error(['message' => 'invalid_payload'], 400);
    }

    $table = scp_friends_table_requests();
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE id = %d LIMIT 1",
        $request_id
    ));

    if (!$row || (int) $row->receiver_id !== $current_user_id || $row->status !== 'pending') {
        wp_send_json_error(['message' => 'not_found_or_forbidden'], 404);
    }

    $next_status = ($decision === 'accept') ? 'accepted' : 'rejected';

    $updated = $wpdb->update(
        $table,
        [
            'status' => $next_status,
            'acted_by' => $current_user_id,
            'updated_at' => current_time('mysql'),
        ],
        [
            'id' => $request_id,
            'status' => 'pending',
        ],
        ['%s', '%d', '%s'],
        ['%d', '%s']
    );

    if ($updated === false) {
        wp_send_json_error(['message' => 'update_failed'], 500);
    }

    wp_send_json_success(['status' => $next_status]);
});

add_action('wp_ajax_scp_remove_friend', function () {
    if (!scp_friends_ensure_table()) {
        wp_send_json_error(['message' => 'friends_table_missing'], 500);
    }

    global $wpdb;

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }

    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'scp-ajax')) {
        wp_send_json_error(['message' => 'invalid_nonce'], 400);
    }

    $target_user_id = isset($_POST['target_user_id']) ? (int) $_POST['target_user_id'] : 0;
    $current_user_id = get_current_user_id();

    if ($target_user_id <= 0 || $target_user_id === $current_user_id || !get_userdata($target_user_id)) {
        wp_send_json_error(['message' => 'invalid_target'], 400);
    }

    $table = scp_friends_table_requests();
    $updated = $wpdb->query($wpdb->prepare(
        "UPDATE {$table}
         SET status = 'removed', acted_by = %d, updated_at = %s
         WHERE status = 'accepted'
           AND ((requester_id = %d AND receiver_id = %d)
             OR (requester_id = %d AND receiver_id = %d))",
        $current_user_id,
        current_time('mysql'),
        $current_user_id,
        $target_user_id,
        $target_user_id,
        $current_user_id
    ));

    if ($updated === false) {
        wp_send_json_error(['message' => 'remove_failed'], 500);
    }

    wp_send_json_success(['state' => 'none']);
});
